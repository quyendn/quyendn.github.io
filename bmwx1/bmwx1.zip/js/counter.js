import {
    CountUp
} from '/js/countUp.js';